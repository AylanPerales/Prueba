package uia.com.contabilidad.clientes;

public class ListaCheques {

	public ListaCheques() {
		super();
		// TODO Auto-generated constructor stub
	}
}
