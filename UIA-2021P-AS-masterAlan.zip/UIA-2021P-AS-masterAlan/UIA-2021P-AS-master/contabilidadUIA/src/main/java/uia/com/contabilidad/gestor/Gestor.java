package uia.com.contabilidad.gestor;

public class Gestor extends AGestor{

	
	public Gestor(String nomFile) {
		super(nomFile);
		// TODO Auto-generated constructor stub
	}


	public void Gestor()
	{	
	}
	
	
	@Override
	public void Print() {
		super.Print();		
	}

	@Override
	public void Lee() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Busca() {
		// TODO Auto-generated method stub
		
	}

}
