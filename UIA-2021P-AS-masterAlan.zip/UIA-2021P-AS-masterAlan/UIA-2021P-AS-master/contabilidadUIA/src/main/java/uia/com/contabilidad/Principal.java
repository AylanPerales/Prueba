package uia.com.contabilidad;

import uia.com.contabilidad.gestor.DecoradorCobranza;
import uia.com.contabilidad.gestor.DecoradorCopras;
import uia.com.contabilidad.gestor.Gestor;

public class Principal {

	public static void main(String[] args) {
		
		
		System.out.println("Hola UIA");
		
		Gestor contabilidad = new Gestor("C:\\TSU-UIA\\contabilidadUIA\\cuentasXCobrar.json");
		
		 DecoradorCobranza gestorCobranza = new DecoradorCobranza(contabilidad);
		 
		 DecoradorCopras compras = new DecoradorCopras(contabilidad);
		 
		 compras.Print();
		 compras.RegistroCheque();
		 
		 gestorCobranza.Print();
		 gestorCobranza.validaCobranza();
		//miGestorClientes.registraCheque("Alfonso", "Cheques", "ClienteX");
		
		
	}


}
