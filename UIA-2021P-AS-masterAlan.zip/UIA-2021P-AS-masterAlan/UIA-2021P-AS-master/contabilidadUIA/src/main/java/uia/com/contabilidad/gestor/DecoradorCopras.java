package uia.com.contabilidad.gestor;

public class DecoradorCopras extends Decorador
{
	public DecoradorCopras(IGestor gestor)
	{
		super(gestor);
	}
	
	public DecoradorCopras()
	{
		
	}
	
	public void validaCopras()
	{
		super.Print();
	}
	
	public void RegistroCheque()
	{
		super.Print();
	}
}
