package uia.com.contabilidad.gestor;

public interface IGestor {
	
	public void Print();
	public void Lee();
	public void Busca();	

}
